﻿
namespace JeuMotATrouver
{
    partial class FormTtt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.bBD = new System.Windows.Forms.Button();
            this.bBM = new System.Windows.Forms.Button();
            this.bBG = new System.Windows.Forms.Button();
            this.bHG = new System.Windows.Forms.Button();
            this.bMG = new System.Windows.Forms.Button();
            this.bMD = new System.Windows.Forms.Button();
            this.bHM = new System.Windows.Forms.Button();
            this.bMM = new System.Windows.Forms.Button();
            this.bHD = new System.Windows.Forms.Button();
            this.bDeuxiemeJ = new System.Windows.Forms.Button();
            this.bNewGame = new System.Windows.Forms.Button();
            this.bJ1 = new System.Windows.Forms.Button();
            this.bJ2 = new System.Windows.Forms.Button();
            this.lblScore = new System.Windows.Forms.Label();
            this.lblScoreJ1 = new System.Windows.Forms.Label();
            this.lblScoreJ2 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.bBD);
            this.panel1.Controls.Add(this.bBM);
            this.panel1.Controls.Add(this.bBG);
            this.panel1.Controls.Add(this.bHG);
            this.panel1.Controls.Add(this.bMG);
            this.panel1.Controls.Add(this.bMD);
            this.panel1.Controls.Add(this.bHM);
            this.panel1.Controls.Add(this.bMM);
            this.panel1.Controls.Add(this.bHD);
            this.panel1.Location = new System.Drawing.Point(12, 117);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(232, 209);
            this.panel1.TabIndex = 0;
            // 
            // bBD
            // 
            this.bBD.Font = new System.Drawing.Font("Ink Free", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bBD.Location = new System.Drawing.Point(150, 135);
            this.bBD.Name = "bBD";
            this.bBD.Size = new System.Drawing.Size(60, 52);
            this.bBD.TabIndex = 18;
            this.bBD.UseVisualStyleBackColor = true;
            this.bBD.Click += new System.EventHandler(this.bBD_Click);
            // 
            // bBM
            // 
            this.bBM.Font = new System.Drawing.Font("Ink Free", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bBM.Location = new System.Drawing.Point(85, 135);
            this.bBM.Name = "bBM";
            this.bBM.Size = new System.Drawing.Size(60, 52);
            this.bBM.TabIndex = 17;
            this.bBM.UseVisualStyleBackColor = true;
            this.bBM.Click += new System.EventHandler(this.bBM_Click);
            // 
            // bBG
            // 
            this.bBG.Font = new System.Drawing.Font("Ink Free", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bBG.Location = new System.Drawing.Point(18, 135);
            this.bBG.Name = "bBG";
            this.bBG.Size = new System.Drawing.Size(60, 52);
            this.bBG.TabIndex = 16;
            this.bBG.UseVisualStyleBackColor = true;
            this.bBG.Click += new System.EventHandler(this.bBG_Click);
            // 
            // bHG
            // 
            this.bHG.Font = new System.Drawing.Font("Ink Free", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bHG.Location = new System.Drawing.Point(18, 19);
            this.bHG.Name = "bHG";
            this.bHG.Size = new System.Drawing.Size(60, 52);
            this.bHG.TabIndex = 15;
            this.bHG.UseVisualStyleBackColor = true;
            this.bHG.Click += new System.EventHandler(this.bHG_Click);
            // 
            // bMG
            // 
            this.bMG.Font = new System.Drawing.Font("Ink Free", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bMG.Location = new System.Drawing.Point(18, 77);
            this.bMG.Name = "bMG";
            this.bMG.Size = new System.Drawing.Size(60, 52);
            this.bMG.TabIndex = 14;
            this.bMG.UseVisualStyleBackColor = true;
            this.bMG.Click += new System.EventHandler(this.bMG_Click);
            // 
            // bMD
            // 
            this.bMD.Font = new System.Drawing.Font("Ink Free", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bMD.Location = new System.Drawing.Point(150, 77);
            this.bMD.Name = "bMD";
            this.bMD.Size = new System.Drawing.Size(60, 52);
            this.bMD.TabIndex = 13;
            this.bMD.UseVisualStyleBackColor = true;
            this.bMD.Click += new System.EventHandler(this.bMD_Click);
            // 
            // bHM
            // 
            this.bHM.Font = new System.Drawing.Font("Ink Free", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bHM.Location = new System.Drawing.Point(84, 19);
            this.bHM.Name = "bHM";
            this.bHM.Size = new System.Drawing.Size(60, 52);
            this.bHM.TabIndex = 12;
            this.bHM.UseVisualStyleBackColor = true;
            this.bHM.Click += new System.EventHandler(this.bHM_Click);
            // 
            // bMM
            // 
            this.bMM.Font = new System.Drawing.Font("Ink Free", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bMM.Location = new System.Drawing.Point(85, 77);
            this.bMM.Name = "bMM";
            this.bMM.Size = new System.Drawing.Size(60, 52);
            this.bMM.TabIndex = 11;
            this.bMM.UseVisualStyleBackColor = true;
            this.bMM.Click += new System.EventHandler(this.bMM_Click);
            // 
            // bHD
            // 
            this.bHD.Font = new System.Drawing.Font("Ink Free", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bHD.Location = new System.Drawing.Point(150, 19);
            this.bHD.Name = "bHD";
            this.bHD.Size = new System.Drawing.Size(60, 52);
            this.bHD.TabIndex = 10;
            this.bHD.UseVisualStyleBackColor = true;
            this.bHD.Click += new System.EventHandler(this.bHD_Click);
            // 
            // bDeuxiemeJ
            // 
            this.bDeuxiemeJ.Location = new System.Drawing.Point(31, 353);
            this.bDeuxiemeJ.Name = "bDeuxiemeJ";
            this.bDeuxiemeJ.Size = new System.Drawing.Size(67, 51);
            this.bDeuxiemeJ.TabIndex = 1;
            this.bDeuxiemeJ.Text = "Deuxième joueur";
            this.bDeuxiemeJ.UseVisualStyleBackColor = true;
            this.bDeuxiemeJ.Click += new System.EventHandler(this.bDeuxiemeJ_Click);
            // 
            // bNewGame
            // 
            this.bNewGame.Location = new System.Drawing.Point(156, 353);
            this.bNewGame.Name = "bNewGame";
            this.bNewGame.Size = new System.Drawing.Size(67, 51);
            this.bNewGame.TabIndex = 2;
            this.bNewGame.Text = "Nouvelle partie";
            this.bNewGame.UseVisualStyleBackColor = true;
            // 
            // bJ1
            // 
            this.bJ1.Location = new System.Drawing.Point(31, 43);
            this.bJ1.Name = "bJ1";
            this.bJ1.Size = new System.Drawing.Size(75, 23);
            this.bJ1.TabIndex = 3;
            this.bJ1.Text = "Joueur 1 : X";
            this.bJ1.UseVisualStyleBackColor = true;
            this.bJ1.Click += new System.EventHandler(this.bJ1_Click);
            // 
            // bJ2
            // 
            this.bJ2.Location = new System.Drawing.Point(148, 43);
            this.bJ2.Name = "bJ2";
            this.bJ2.Size = new System.Drawing.Size(75, 23);
            this.bJ2.TabIndex = 4;
            this.bJ2.Text = "Ordi : O";
            this.bJ2.UseVisualStyleBackColor = true;
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.Location = new System.Drawing.Point(106, 76);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(41, 13);
            this.lblScore.TabIndex = 5;
            this.lblScore.Text = "Score :";
            // 
            // lblScoreJ1
            // 
            this.lblScoreJ1.AutoSize = true;
            this.lblScoreJ1.Location = new System.Drawing.Point(93, 95);
            this.lblScoreJ1.Name = "lblScoreJ1";
            this.lblScoreJ1.Size = new System.Drawing.Size(13, 13);
            this.lblScoreJ1.TabIndex = 6;
            this.lblScoreJ1.Text = "0";
            // 
            // lblScoreJ2
            // 
            this.lblScoreJ2.AutoSize = true;
            this.lblScoreJ2.Location = new System.Drawing.Point(145, 95);
            this.lblScoreJ2.Name = "lblScoreJ2";
            this.lblScoreJ2.Size = new System.Drawing.Size(13, 13);
            this.lblScoreJ2.TabIndex = 7;
            this.lblScoreJ2.Text = "0";
            // 
            // timer1
            // 
            this.timer1.Interval = 20000;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(9, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Tour Joueur 1";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(169, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Tour n° 1";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // FormTtt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(267, 427);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblScoreJ2);
            this.Controls.Add(this.lblScoreJ1);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.bJ2);
            this.Controls.Add(this.bJ1);
            this.Controls.Add(this.bNewGame);
            this.Controls.Add(this.bDeuxiemeJ);
            this.Controls.Add(this.panel1);
            this.Name = "FormTtt";
            this.Text = "Form3";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button bDeuxiemeJ;
        private System.Windows.Forms.Button bNewGame;
        private System.Windows.Forms.Button bJ1;
        private System.Windows.Forms.Button bBD;
        private System.Windows.Forms.Button bBM;
        private System.Windows.Forms.Button bBG;
        private System.Windows.Forms.Button bHG;
        private System.Windows.Forms.Button bMG;
        private System.Windows.Forms.Button bMD;
        private System.Windows.Forms.Button bHM;
        private System.Windows.Forms.Button bMM;
        private System.Windows.Forms.Button bHD;
        private System.Windows.Forms.Button bJ2;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Label lblScoreJ1;
        private System.Windows.Forms.Label lblScoreJ2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}